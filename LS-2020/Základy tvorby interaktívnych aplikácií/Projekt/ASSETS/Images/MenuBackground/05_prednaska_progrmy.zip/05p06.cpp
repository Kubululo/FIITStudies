// nacitanie najviac N prvych roznych slov do N-prvkoveho pola struktur
#include <stdio.h>
#include <string.h>
#define N 20		// maximalna dlzka slovnika
#define NSLOVA 100 	// maximalna dlzka slova
#define SUBOR "slova.txt"

typedef struct {
	char slovo[NSLOVA];	// pole znakov o velkosti NSLOVA
	int pocet;			// pocet vyskytov
} ZAZNAM;

int nacitaj(ZAZNAM slovnik[]) {
	int i, n = 0;
	char slovo[NSLOVA];
	FILE *f;
	
	for(i=0; i<N; i++) {
		slovnik[i].pocet = 0;
		slovnik[i].slovo[0] = '\0';
	}
	
	if((f = fopen(SUBOR, "r")) == NULL) {
		printf("Nepodarilo sa otvorit subor\n");
		return 0;
	}
	while(fscanf(f, "%s", slovo) == 1) {
		for(i=0; i<n; i++) 
			if(!strcmp(slovnik[i].slovo, slovo)) 
				break;
		if(i < n) // slovo sa v slovniku nachadza
			slovnik[i].pocet++;
		else if(n<N){
			strcpy(slovnik[i].slovo, slovo);
			slovnik[i].pocet = 1;
			n++;
		}
	}
	fclose(f);
 	return n;
}


int main() {
	ZAZNAM slovnik[N];
	int i, n;
	n = nacitaj(slovnik);
	for(i=0; i<n; i++)
		printf("%s (%d)\n", slovnik[i].slovo, slovnik[i].pocet);
	return 0;
}
