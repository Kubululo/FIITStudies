// rozdiel v casoch: cas konca (napr. stretnutia) - cas zaciatku
// CAS: typ definovany pomocou struktury
#include <stdio.h>

// definovany typ CAS
typedef struct {
    int sekundy;
    int minuty;
    int hodiny;
} CAS;


int main() {
    CAS start, stop, rozdiel;	// premenne typu CAS
    printf("Zadajte cas zaciatku: hodiny, minuty a sekundy: ");
    scanf("%d %d %d", &start.hodiny, &start.minuty, &start.sekundy);
    printf("Zadajte cas konca: hodiny, minuty a sekundy: ");
    scanf("%d %d %d", &stop.hodiny, &stop.minuty, &stop.sekundy);

    if (start.sekundy > stop.sekundy) {
        --stop.minuty;
        stop.sekundy += 60;
    }
    rozdiel.sekundy = stop.sekundy - start.sekundy;
    
    if (start.sekundy > stop.minuty) {
        --stop.hodiny;
        stop.minuty += 60;
    }
    rozdiel.minuty = stop.minuty - start.minuty;
    rozdiel.hodiny = stop.hodiny - start.hodiny;
    
    printf("\nRozdiel v casoch: %02d:%02d:%02d -> ", start.hodiny, start.minuty, start.sekundy);
    printf("%02d:%02d:%02d", stop.hodiny, stop.minuty, stop.sekundy);
    printf(" je %02d:%02d:%02d\n", rozdiel.hodiny, rozdiel.minuty, rozdiel.sekundy);
    return 0;
}

