// vypisanie vsetkych podmatic matice s danym suctom
#include <stdio.h>
#include <stdlib.h>
#define SUBOR "matica.txt"

int **nacitaj(int **m, int *r, int *s);
void vypisPodmatice(int **m, int r, int s, int suma);

int main() {
	int **matica;
	int r, s, sum;
		
	printf("Zadajte sumu podmatice: ");
	scanf("%d", &sum);
	matica = nacitaj(matica, &r, &s);
	vypisPodmatice(matica, r, s, sum);
	return 0;
}

int ** nacitaj(int **m, int *r, int *s) {
	FILE *f;
	int i, j;
	
	if ((f = fopen(SUBOR, "r")) == NULL) {
		printf("Nepodarilo sa otvorit subor\n");
		exit(0);
	}
	fscanf(f, "%d %d", r, s);
	printf("Riadky: %d, stlpce: %d\n", *r, *s);
	m = (int **) malloc (*r * sizeof(int *));
	for (i=0; i<*r; i++)
		m[i] = (int *) malloc (*s * sizeof(int));	
	for (i=0; i<*r; i++) 
		for (j=0; j<*s; j++) 
			fscanf(f, "%d", &m[i][j]);
		
	
	for (i=0; i<*r; i++) {
		for (j=0; j<*s; j++)
			printf("%d ", m[i][j]);
		printf("\n");
	}
	fclose(f);
	return m;
}

void vypisPodmatice(int **m, int r, int s, int suma) {
	int i, j, k, l, dr, ds, sum;
	
	for(i=0; i<r; i++) // index riadku laveho horneho rohu podmatice
		for(j=0; j<s; j++) // index stlpca laveho horneho rohu podmatice
			for(dr=1; dr<=r-i; dr++)	// pocet riadkov podmatice
				for(ds=1; ds<=s-j; ds++) {// pocet stlpcov podmatice
					sum = 0;
					for(k=i; k<i+dr; k++) 
						for(l=j; l<j+ds; l++)
							sum += m[k][l];
					if (sum == suma) {
						printf("Podmatica zacinajuca na indexoch [%d][%d]: \n", i, j);
						for(k=i; k<i+dr; k++) {
							for(l=j; l<j+ds; l++)
								printf("%d ", m[k][l]);
							printf("\n");
						}
					}
				}
}

