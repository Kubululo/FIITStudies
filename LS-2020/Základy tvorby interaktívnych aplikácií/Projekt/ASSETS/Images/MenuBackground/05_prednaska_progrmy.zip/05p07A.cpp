// nacitanie a vypis tried so ziakmi - pouzitie struktur
// student: struktura pre zaznam o 1 studentovi
// triedy: struktura pre zaznam o 1 triede, obsahuje ukazovatel na zoznam studentov
// skola: premenna - pole tried
#include <stdio.h>
#include <stdlib.h>
#define NTRIED 20	// pocet tried
#define NMENO 30	// dlzka mena
#define SUBOR "skola.txt"

// definovane typy: struktura a ukazovatel na strukturu pre 1 studenta
typedef struct {
    char meno[NMENO];
	char priez[NMENO];
    double priemer;
} STUDENT, *P_STUDENT;

// definovanie typu pre 1 triedu  
typedef struct {
	char nazov[NMENO];
	int pocet;  	  // pocet studentov v triede
	P_STUDENT zoznam; // ukazovatel na zoznam studentov
} TRIEDA;

int nacitaj(TRIEDA skola[]) {
	int i, n=0;
	
	FILE *f;
	
	if((f = fopen(SUBOR, "r")) == NULL) {
		printf("Nepodarilo sa otvorit subor\n");
		return 0;
	}
	while(n<NTRIED && fscanf(f, "%s", skola[n].nazov) == 1) {
		fscanf(f, "%d", &skola[n].pocet);
		skola[n].zoznam = (P_STUDENT) malloc(skola[n].pocet * sizeof(STUDENT));
		for(i=0; i<skola[n].pocet; i++) {
			fscanf(f, "%s", skola[n].zoznam[i].meno);
			fscanf(f, "%s", skola[n].zoznam[i].priez);
			fscanf(f, "%lf", &skola[n].zoznam[i].priemer);
		}
		n++;
	}
	fclose(f);
	return n;
}

void vypis(TRIEDA skola[], int n) {
	int i, j;
	
	printf("Zoznam ziakov tried: \n");
	for(i=0; i<n; i++) {
		printf("%s %d\n", skola[i].nazov, skola[i].pocet);
		for(j=0; j<skola[i].pocet; j++) {
			printf("  %s %s %.2f\n", skola[i].zoznam[j].meno, skola[i].zoznam[j].priez,
				skola[i].zoznam[j].priemer);
		}
	}
}

int main() {
	TRIEDA skola[NTRIED]; // pole tried
	int n;
	
	n = nacitaj(skola);
	vypis(skola, n);
	return 0;
}
