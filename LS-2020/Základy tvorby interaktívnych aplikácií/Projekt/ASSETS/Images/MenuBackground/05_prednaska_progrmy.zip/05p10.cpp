// dynamicke vytvaranie struktury vo funkcii
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define NMENO 30

// definovany typ pre zaznam o studentovi
typedef struct {
    char meno[NMENO];
    char priez[NMENO];
    double priemer;
} STUDENT;

// dynamicke vytvorenie zaznamu o studentovu a vratenie cez navrtovu hodnotu
STUDENT *vytvor1(void) {
    STUDENT *p;
    p = (STUDENT *) malloc(sizeof(STUDENT));
    if (p == NULL) 
        printf("Malo pamate.\n");
    return p;
}

// dynamicke vytvorenie zaznamu o studentovi a vratenie cez argument funkcie
void vytvor2(STUDENT **p) {
    *p = (STUDENT *) malloc(sizeof(STUDENT));
    if (*p == NULL) 
        printf("Malo pamate.\n");
}

void nastav(STUDENT *p, char *meno, char *priez, double priemer) {
    p->priemer = priemer;
    strcpy(p->meno, meno);
    strcpy(p->priez, priez);
}

void vypis(STUDENT *p_s) {
	printf("Meno: %s priezvisko: %s: priemer, %f\n", p_s->meno,
	p_s->priez, p_s->priemer);
}

int main() 
{
    STUDENT  s, *p_s1, *p_s2;
    p_s1 = vytvor1();
    vytvor2(&p_s2);
    s.priemer = p_s1->priemer = 1;
    nastav(&s, "Martin", "Maly", 1.2);
    nastav(p_s1, "Peter", "Kovac", 2.1);
    nastav(p_s2, "Michal", "Novak", 3);
    vypis(&s);
    vypis(p_s1);
    vypis(p_s2);
    return 0;
}


