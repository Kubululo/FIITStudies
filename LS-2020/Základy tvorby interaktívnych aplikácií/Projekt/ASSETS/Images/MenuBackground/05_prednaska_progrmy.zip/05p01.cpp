// kontrola sudoku: riadky a stlpce
#include <stdio.h>
#include <stdlib.h>
#define N 9 // rozmer sudoku
#define SUBOR "sudoku.txt"

void nacitaj(int sudoku[][N]);
int skontrolujRiadok(int sudoku[][N], int riadok);
int skontrolujStlpec(int sudoku[][N], int stlpeca);

int main() {
	int sudoku[N][N];			// dvojrozmerne pole pre sudoku
	int i;
		
	nacitaj(sudoku);
	
	// kontrola riadkov
	for (i=0; i<N; i++)
		if (!skontrolujRiadok(sudoku, i))
			break;
	if (i<N) {
		printf("Riadok %d nie je spravne vyplneny.\n", i);
		return 0;
	}		
	else
		printf("Riadky su spravne vyplnene.\n", i);
	
	// kontrola stlpcov
	for (i=0; i<N; i++)
		if (!skontrolujStlpec(sudoku, i))
			break;
	if (i<N){
		printf("Stlpec %d nie je spravne vyplneny.\n", i);
		return 0;
	}
	else
		printf("Stlpce su spravne vyplnene.\n", i);
	return 0;
}

// funkcia nacita sudoku zo suboru
void nacitaj(int sudoku[][N]) {
	FILE *f;
	int i, j;
	
	if ((f = fopen(SUBOR, "r")) == NULL) {
		printf("Nepodarilo sa otvorit subor\n");
		exit(0);
	}
	for (i=0; i<N; i++) 
		for (j=0; j<N; j++)
			fscanf(f, "%d", &sudoku[i][j]);
	
	fclose(f);
}

// funkcia kontroluje riadok sudoku dany argumentom riadok
int skontrolujRiadok(int sudoku[][N], int riadok) {
	int i, k=1;
	int kontrola[N] = {0};	// pole pomocou ktoreho kontrolujeme riadok
	
	for(i=0; i<N; i++) {
		if (sudoku[riadok][i] < 1 || sudoku[riadok][i] > 9 || 
			kontrola[sudoku[riadok][i]-1] == k) 
			return 0;
		kontrola[sudoku[riadok][i]-1] = k;
	}
	return 1;
}

// funkcia kontroluje stlpec sudoku dany argumentom stlpec
int skontrolujStlpec(int sudoku[][N], int stlpec) {
	int i, k=1;
	int kontrola[N] = {0};	// pole pomocou ktoreho kontrolujeme stlpec
	
	for(i=0; i<N; i++) {
		if (sudoku[i][stlpec] < 1 || sudoku[i][stlpec] > 9 || 
			kontrola[sudoku[i][stlpec]-1] == k) 
			return 0;
		kontrola[sudoku[i][stlpec]-1] = k;
	}
	return 1;
}
