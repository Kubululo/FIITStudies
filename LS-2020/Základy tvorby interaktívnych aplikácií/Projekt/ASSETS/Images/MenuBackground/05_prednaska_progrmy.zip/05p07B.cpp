// nacitanie a vypis tried so ziakmi - pouzitie struktur 
// zmena oproti 05p07A: pouzitie ukazovatela na pristup do pola struktur vo funkcii vypis()
// student: struktura pre zaznam o 1 studentovi
// triedy: struktura pre zaznam o 1 triede, obsahuje ukazovatel na zoznam studentov
// skola: premenna - pole tried
#include <stdio.h>
#include <stdlib.h>
#define NTRIED 20	// pocet tried
#define NMENO 30	// dlzka mena
#define SUBOR "skola.txt"

typedef struct {
    char meno[NMENO];
	char priez[NMENO];
    double priemer;
} STUDENT, *P_STUDENT;

typedef struct {
	char nazov[NMENO];
	int pocet;
	P_STUDENT zoznam;	
} TRIEDA;

int nacitaj(TRIEDA skola[]) {
	int i, n=0;
	FILE *f;
	
	if((f = fopen(SUBOR, "r")) == NULL) {
		printf("Nepodarilo sa otvorit subor\n");
		return 0;
	}
	while(n<NTRIED && fscanf(f, "%s", skola[n].nazov) == 1) {
		fscanf(f, "%d", &skola[n].pocet);
		skola[n].zoznam = (P_STUDENT) malloc(skola[n].pocet * sizeof(STUDENT));
		for(i=0; i<skola[n].pocet; i++) {
			fscanf(f, "%s", skola[n].zoznam[i].meno);
			fscanf(f, "%s", skola[n].zoznam[i].priez);
			fscanf(f, "%lf", &skola[n].zoznam[i].priemer);
		}
		n++;
	}
	fclose(f);
	return n;
}

// vypis: pouzitie pomocneho ukazovatela
void vypis(TRIEDA skola[], int n) {
	int i;
	P_STUDENT p;	// pomocny ukazovatel na pristup k prvkom triedy (studentom)
	
	printf("Zoznam ziakov tried: \n");
	for(i=0; i<n; i++) {
		printf("%s %d\n", skola[i].nazov, skola[i].pocet);
		for(p=skola[i].zoznam; p<skola[i].zoznam + skola[i].pocet; p++) {
			printf("  %s %s %.2f\n", p->meno, p->priez,	p->priemer);
		}
	}
}

int main() {
	TRIEDA skola[NTRIED];
	int n;
	
	n = nacitaj(skola);
	vypis(skola, n);
	return 0;
}
