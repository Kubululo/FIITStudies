// nacitanie a scitanie komplexnych cisel 
// vratenie struktury z funkcie - cez navratovu hodnotu, cez argument
#include <stdio.h>

typedef struct {
    double re, im;
} KOMP;

// vratenie cez navratovu hodnotu
KOMP sucet1(KOMP a, KOMP b) {
    KOMP c;

    c.re = a.re + b.re;
    c.im = a.im + b.im;
    return c;
}

// vratenie cez argument
void sucet2(KOMP *a, KOMP *b, KOMP *c) {
    c->re = a->re + b->re;
    c->im = a->im + b->im;
}

int main()
{
    KOMP x, y, z;
    printf("Zadajte 1. komplexne cislo:\n");
    printf(" - realnu zlozku: ");
    scanf("%lf", &x.re);
	printf(" - imaginarnu zlozku: ");
    scanf("%lf", &x.im);
    
    printf("\nZadajte 2. komplexne cislo:\n");
    printf(" - realnu zlozku: ");
    scanf("%lf", &y.re);
	printf(" - imaginarnu zlozku: ");
    scanf("%lf", &y.im);
	
	z = sucet1(x, y);
	printf("\nSucet1: (%.2f + %.2fi) + (%.2f + %.2fi)= %.2f + %.2fi\n", 
		x.re, x.im, y.re, y.im, z.re, z.im);
	
	sucet2(&x, &y, &z);
	printf("\nSucet2: (%.2f + %.2fi) + (%.2f + %.2fi)= %.2f + %.2fi\n", 
		x.re, x.im, y.re, y.im, z.re, z.im);
	
    return 0;
}

