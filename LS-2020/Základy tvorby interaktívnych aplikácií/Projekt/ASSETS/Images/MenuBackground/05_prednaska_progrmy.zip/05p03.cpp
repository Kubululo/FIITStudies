// vypis grafikonu z nacitanych casov
#include <stdio.h>
#define NH 24	// max. pocet hodin
#define NM 60   // max. pocet minut

int main(int argc, char *argv[]) {
 	int h, m;
	int g[NH][NM] = {{0}};  // dvojrozmerne pole poctov vyskytov jednotlivych casov
	int c[NH] = {0}; 		// pole s poctami nacitanych casov pre jednotlive hodiny
	FILE *f;
	
	// ak mame 1 parameter funcie, tak je to nazov suboru 
	if (argc != 2 || (f = fopen(argv[1], "r")) == NULL) {
		f = stdin;
		printf("Zadavajte vo formate HH:MM, pre koniec vlozte neciselny znak\n");
	}
	else
		printf("Casy prichodov sa nacitaju zo suboru %s\n", argv[1]);
	
	// nacitanie casov
    while (fscanf(f, "%d:%d", &h, &m) > 0) {
    	g[h][m]++;
    	c[h]++;
  	}
  	
  	// vypis grafikonu
  	printf("\nGrafikon\n");
  	for (h = 0; h < NH; h++) {
  		if (c[h]>0) {
  			printf("%02d |", h);

      		for (m = 0; m < NM; m++)
        		while (g[h][m] > 0) {
	  				printf(" %02d", m);
          			g[h][m]--;
        		}
      		printf("\n");
      	}
    }
    if (f != stdin)
    	fclose(f);
  	return 0;
}

